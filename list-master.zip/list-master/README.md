The Public Suffix List
======================

A "public suffix" is one under which Internet users can (or historically could)
directly register names. Some examples of public suffixes are .com, .co.uk and
pvt.k12.ma.us. The Public Suffix List is a list of all known public suffixes.

See https://publicsuffix.org/ and the [Wiki](https://github.com/publicsuffix/list/wiki) link above for more information.

[![Build Status](https://travis-ci.org/publicsuffix/list.svg?branch=master)](https://travis-ci.org/publicsuffix/list)

Important Notice:
2021-04-23 : Did guidance related to an issue with Facebook or Apple bring you here?  [Read this before submitting requests](https://github.com/publicsuffix/list/issues/1245)
